# include <stdio.h>
int main() 
{
    int a,b,c;
    printf("Enter First Number\n");
    scanf("%d", & a);
    printf("Enter Second Number\n");
    scanf("%d", & b);
    c=(a+b);
    printf("the addition of two number is\n %d", c);
    return 0;
}